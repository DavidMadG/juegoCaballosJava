 import java.util.Random;
 class caballo implements Runnable { //implemeto el runnable para ejecutar acciones en paralelo
    private String nombre;
    private int tiempo;

    caballo(String nombre){ //objeto caballo
        this.nombre = nombre;
    }
    public String getNombre(){ //metodo para obtener el nombre
        return nombre; 
    }
    public int getTiempo(){ //instancio el tiempo para poder llamarlo despues y saber el ganador
        return tiempo;
    }
    public void run(){ //metodo run para ejecutar los hilos
        Random random = new Random();
         tiempo = random.nextInt(10); //metodo Random para que me de un numero aleatorio hasta el 10
        try {
                Thread.sleep(tiempo * 500);
                System.out.println("El caballo " + nombre + " ha tardado " + tiempo + " segundos");
            
        } catch (Exception e) {
            e.getMessage();
        }
    }
}
