
import java.util.Scanner;

public class carreraCaballos {

    public static void main(String[] args) throws InterruptedException {
        int dinero = 100;
        Scanner sc = new Scanner(System.in);

        System.out.println("===Bienvenidos===");
        System.out.print("Dame el nombre del primer caballo: ");
        String caballo1 = sc.nextLine();
        System.out.print("Dame el nombre del segundo caballo: ");
        String caballo2 = sc.nextLine();
        System.out.print("Dame el nombre del tercero caballo: ");
        String caballo3 = sc.nextLine();
        do { //bucle con do/while hasta que tengas 0 de dinero
            System.out.print("Tienes " + dinero + "€" + "¿Cuanto dinero quieres apostar?: ");
            int apuesta = sc.nextInt();
            if (apuesta > dinero) {
                System.out.print("No tienes ese dinero para apostar.... ");
                continue; //para volver al inicio del do/while y que te pida otra vez la apuesta.
            }
            //menu para elegir el caballo
            System.out.println("¿A que caballo quieres apostar? ");
            System.out.println("1.Caballo1 ");
            System.out.println("2.Caballo2 ");
            System.out.println("3.Caballo3 ");
            System.out.print("Elige una opcion: ");
            int opcion = sc.nextInt();

            System.out.println("Sale " + caballo1);
            System.out.println("Sale " + caballo2);
            System.out.println("Sale " + caballo3);
            //Creo los 3 caballos objeto
            caballo tarea1 = new caballo(caballo1);
            caballo tarea2 = new caballo(caballo2);
            caballo tarea3 = new caballo(caballo3);
            //Ejecuto las 3 tareas simultaneamente
            Thread t = new Thread(tarea1);
            t.start();
            Thread t1 = new Thread(tarea2);
            t1.start();
            Thread t2 = new Thread(tarea3);
            t2.start();
            //Metodo Join para hacer calculos mas adelante.
            t.join();
            t1.join();
            t2.join();

            int tiempo = Math.min(tarea1.getTiempo(), Math.min(tarea2.getTiempo(), tarea3.getTiempo())); //Saco el minimo tiempo de los 3 caballos
            String caballoGanador; // hago una variable para poner el nombre del caballo ganador
            //Comparacion para que me saque el nombre del caballo ganador, este metodo es erroneo si hay un 4º caballo.
            if (tarea1.getTiempo() == tiempo) {
                caballoGanador = tarea1.getNombre();
            } else if (tarea2.getTiempo() == tiempo) {
                caballoGanador = tarea2.getNombre();
            } else {
                caballoGanador = tarea3.getNombre();
            }
            System.out.println("El ganador es: " + caballoGanador);
            //Comparaciones para ver si has elegido el caballo correcto con equals
            if (opcion == 1 && caballo1.equals(caballoGanador)) {
                dinero += apuesta;
                System.out.println("Has ganado!! ahora tienes: " + dinero + "€");
            } else if (opcion == 2 && caballo2.equals(caballoGanador)) {
                dinero += apuesta;
                System.out.println("Has ganado!! ahora tienes: " + dinero + "€");
            } else if (opcion == 3 && caballo3.equals(caballoGanador)) {
                dinero += apuesta;
                System.out.println("Has ganado!! ahora tienes: " + dinero + "€");
            } else {
                dinero -= apuesta;
                System.out.println("Has perdido!!! este es tu dinero total: " + dinero + "€");
            }
        } while (dinero > 0);
        if (dinero == 0) {
            System.out.println("Te has arruinado!! Juega con moderacion jeje");
        } else {
            System.out.println("Te has quedado con: " + dinero + "€");
        }
    }
}
